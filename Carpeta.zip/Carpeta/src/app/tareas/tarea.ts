export class Tarea {
    id: number;
    nomTarea: String;
    descripcion: String;
    fechaCreacion: String;
    responsable: String;
    email: String;
}
